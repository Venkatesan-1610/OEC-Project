import React, { useState, useEffect } from "react";
import ReactSelect from "react-select";
import { assignUsers, removeUsers, getUsers } from "../../../api/api";

const PlanProcedureItem = ({ procedure }) => {
    const [selectedUsers, setSelectedUsers] = useState([]);
    const [allUsers, setAllUsers] = useState([]);

    useEffect(() => {
        const fetchUsersAndAssignments = async () => {
            try {
                const response = await getUsers(procedure.procedureId);

                const userOptions = response.map(user => ({
                    value: user.userId,
                    label: user.name,
                }));
                setAllUsers(userOptions);

                const assignedOptions = response
                    .filter(user => user.assignedProcedureId === procedure.procedureId)
                    .map(user => ({
                        value: user.userId,
                        label: user.name,
                    }));
                setSelectedUsers(assignedOptions);
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        };

        fetchUsersAndAssignments();
    }, [procedure.procedureId]);

    const handleAssignUserToProcedure = async (selectedOptions) => {
        const newlyAssignedUsers = selectedOptions.map(option => ({
            userId: option.value,
            userName: option.label,
        }));

        const previouslyAssignedUserIds = selectedUsers.map(user => user.value);
        const newlyAssignedUserIds = newlyAssignedUsers.map(user => user.userId);

        const usersToRemove = previouslyAssignedUserIds.filter(id => !newlyAssignedUserIds.includes(id));
        const usersToAdd = newlyAssignedUsers.filter(user => !previouslyAssignedUserIds.includes(user.userId));

        try {
            if (usersToAdd.length > 0) {
                await assignUsers(procedure.procedureId, usersToAdd);
            }
            if (usersToRemove.length > 0) {
                await removeUsers(procedure.procedureId, usersToRemove);
            }

            const updatedUsers = await getUsers(procedure.procedureId);
            const updatedSelectedUsers = updatedUsers
                .filter(user => user.assignedProcedureId === procedure.procedureId)
                .map(user => ({
                    value: user.userId,
                    label: user.name,
                }));
            setSelectedUsers(updatedSelectedUsers);
        } catch (error) {
            console.error("Error updating users:", error);
        }
    };

    const customComponents = {
        ClearIndicator: () => null
    };

    return (
        <div className="py-2">
            <div>{procedure.procedureTitle}</div>

            <ReactSelect
                className="mt-2"
                placeholder="Select User to Assign"
                isMulti={true}
                options={allUsers}
                value={selectedUsers}
                onChange={handleAssignUserToProcedure}
                components={customComponents}
            />
        </div>
    );
};

export default PlanProcedureItem;

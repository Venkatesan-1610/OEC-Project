using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.EntityFrameworkCore;
using RL.Backend.Commands;
using RL.Data;
using RL.Data.DataModels;
using MediatR;


namespace RL.Backend.Controllers;


[ApiController]
[Route("[controller]")]
public class UsersController : ControllerBase
{
    private readonly ILogger<UsersController> _logger;
    private readonly RLContext _context;
    private readonly IMediator _mediator;

    public class UserResponse
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public int? AssignedProcedureId { get; set; }
    }


    public UsersController(ILogger<UsersController> logger, RLContext context, IMediator mediator)
    {
        _logger = logger;
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
    }

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] int? procedureId)
    {
        try
        {
            // Fetch all users
            var allUsers = await _context.Users
                .Select(user => new UserResponse
                {
                    UserId = user.UserId,
                    Name = user.Name,
                    AssignedProcedureId = null 
                })
                .ToListAsync();

            if (procedureId.HasValue)
            {
                var assignments = await _context.procedureUserAssignments
                    .Where(pua => pua.ProcedureId == procedureId.Value)
                    .Select(pua => new { pua.UserId, pua.ProcedureId })
                    .ToListAsync();

                foreach (var user in allUsers)
                {
                    var assignment = assignments.FirstOrDefault(a => a.UserId == user.UserId);
                    if (assignment != null)
                    {
                        user.AssignedProcedureId = assignment.ProcedureId;
                    }
                }
            }

            return Ok(allUsers);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving users");
            return StatusCode(500, "Internal server error");
        }
    }


    [HttpPost("{procedureId}/assign")]
    public async Task<IActionResult> AssignUsersToProcedure(int procedureId, [FromBody] List<AssignUser> users)
    {
        if (users == null || !users.Any())
        {
            return BadRequest("Users list is empty");
        }

        try
        {
            var command = new AddUserToProcedureCommand
            {
                ProcedureId = procedureId,
                Users = users
            };

            var result = await _mediator.Send(command);
            if (result.Succeeded)
            {
                return Ok();
            }

            return StatusCode(500, "Internal server error");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error assigning users to procedure");
            return StatusCode(500, "Internal server error");
        }
    }

    [HttpDelete("{procedureId}/delete")]
    public async Task<IActionResult> RemoveUsersFromProcedure(int procedureId, [FromBody] List<int> userIds)
    {
        if (userIds == null || !userIds.Any())
        {
            return BadRequest("User IDs list is empty");
        }

        try
        {
            var command = new DeleteUserFromProcedureCommand
            {
                ProcedureId = procedureId,
                UserIds = userIds
            };

            var result = await _mediator.Send(command);
            if (result.Succeeded)
            {
                return Ok();
            }

            return StatusCode(500, "Internal server error");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error removing users from procedure");
            return StatusCode(500, "Internal server error");
        }
    }

}


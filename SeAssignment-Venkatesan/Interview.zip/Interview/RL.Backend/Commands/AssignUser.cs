﻿using MediatR;
using RL.Backend.Models;

namespace RL.Backend.Commands
{
    public class AssignUser
    {
        public int UserId { get; set; }
        public string? UserName { get; set; }
    }

    public class AddUserToProcedureCommand : IRequest<ApiResponse<Unit>>
    {
        public int ProcedureId { get; set; }
        public List<AssignUser> Users { get; set; }
    }

    public class DeleteUserFromProcedureCommand : IRequest<ApiResponse<Unit>>
    {
        public int ProcedureId { get; set; }
        public List<int> UserIds { get; set; }
    }



}

﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using RL.Backend.Exceptions;
using RL.Backend.Models;
using RL.Data;
using RL.Data.DataModels;

namespace RL.Backend.Commands.Handlers.Users
{
    public class AddUserToProcedureCommandHandler : IRequestHandler<AddUserToProcedureCommand, ApiResponse<Unit>>
    {
        private readonly RLContext _context;

        public AddUserToProcedureCommandHandler(RLContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<ApiResponse<Unit>> Handle(AddUserToProcedureCommand request, CancellationToken cancellationToken)
        {
            if (request.ProcedureId < 1)
                return ApiResponse<Unit>.Fail(new BadRequestException("Invalid ProcedureId"));

            var procedure = await _context.Procedures
                .FirstOrDefaultAsync(p => p.ProcedureId == request.ProcedureId, cancellationToken);

            if (procedure == null)
                return ApiResponse<Unit>.Fail(new NotFoundException("Procedure not found."));

            var userIds = request.Users.Select(u => u.UserId).ToList();
            var users = await _context.Users
             .Where(u => userIds.Contains(u.UserId))
             .ToListAsync(cancellationToken);

            if (users.Count != userIds.Count)
            {
                Console.WriteLine("Users retrieved:");
                foreach (var user in users)
                {
                    Console.WriteLine($"UserId: {user.UserId}, UserName: {user.Name}");
                }

                return ApiResponse<Unit>.Fail(new NotFoundException("One or more users not found."));
            }

            var currentAssignments = await _context.procedureUserAssignments
                .Where(pu => pu.ProcedureId == request.ProcedureId)
                .ToListAsync(cancellationToken);

            foreach (var user in request.Users)
            {
                if (!currentAssignments.Any(pu => pu.UserId == user.UserId))
                {
                    var newAssignment = new ProcedureUserAssignment
                    {
                        ProcedureId = request.ProcedureId,
                        UserId = user.UserId,
                        UserName = user.UserName,
                        AssignedDate = DateTime.UtcNow
                    };
                    _context.procedureUserAssignments.Add(newAssignment);
                }
            }

            await _context.SaveChangesAsync(cancellationToken);
            return ApiResponse<Unit>.Succeed(Unit.Value);
        }
    }
}

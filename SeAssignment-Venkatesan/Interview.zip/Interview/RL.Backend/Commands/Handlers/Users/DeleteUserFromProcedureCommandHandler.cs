﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.EntityFrameworkCore;
using RL.Data;
using RL.Backend.Commands;
using RL.Backend.Exceptions;
using RL.Backend.Models;

namespace RL.Backend.Commands.Handlers.Users
{
    public class DeleteUserFromProcedureCommandHandler : IRequestHandler<DeleteUserFromProcedureCommand, ApiResponse<Unit>>
    {
        private readonly RLContext _context;

        public DeleteUserFromProcedureCommandHandler(RLContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<ApiResponse<Unit>> Handle(DeleteUserFromProcedureCommand request, CancellationToken cancellationToken)
        {
            if (request.ProcedureId < 1)
                return ApiResponse<Unit>.Fail(new ArgumentException("Invalid ProcedureId"));

            var assignmentsToDelete = await _context.procedureUserAssignments
                .Where(pu => pu.ProcedureId == request.ProcedureId && request.UserIds.Contains(pu.UserId))
                .ToListAsync(cancellationToken);

            if (!assignmentsToDelete.Any())
            {
                return ApiResponse<Unit>.Succeed(Unit.Value);
            }

            _context.procedureUserAssignments.RemoveRange(assignmentsToDelete);
            await _context.SaveChangesAsync(cancellationToken);

            return ApiResponse<Unit>.Succeed(Unit.Value);
        }
    }
}

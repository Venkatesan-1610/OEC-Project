﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RL.Data.Migrations
{
    public partial class ProcedureUserAssignmentUpdated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ProcedureId1",
                table: "procedureUserAssignments",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_procedureUserAssignments_ProcedureId1",
                table: "procedureUserAssignments",
                column: "ProcedureId1");

            migrationBuilder.AddForeignKey(
                name: "FK_procedureUserAssignments_Procedures_ProcedureId1",
                table: "procedureUserAssignments",
                column: "ProcedureId1",
                principalTable: "Procedures",
                principalColumn: "ProcedureId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_procedureUserAssignments_Procedures_ProcedureId1",
                table: "procedureUserAssignments");

            migrationBuilder.DropIndex(
                name: "IX_procedureUserAssignments_ProcedureId1",
                table: "procedureUserAssignments");

            migrationBuilder.DropColumn(
                name: "ProcedureId1",
                table: "procedureUserAssignments");
        }
    }
}

using System.ComponentModel.DataAnnotations;
using RL.Data.DataModels.Common;

namespace RL.Data.DataModels;

public class Procedure : IChangeTrackable
{
    [Key]
    public int ProcedureId { get; set; }
    public string ProcedureTitle { get; set; }
    public DateTime CreateDate { get; set; }
    public DateTime UpdateDate { get; set; }

    public ICollection<ProcedureUserAssignment> ProcedureUserAssignments { get; set; }

}
public class ProcedureWithAssignedUsers
{
    public int ProcedureId { get; set; }
    public string? ProcedureTitle { get; set; }
    public List<UserDTO>? AssignedUsers { get; set; }
}

public class UserDTO
{
    public int UserId { get; set; }
    public string Name { get; set; }
}



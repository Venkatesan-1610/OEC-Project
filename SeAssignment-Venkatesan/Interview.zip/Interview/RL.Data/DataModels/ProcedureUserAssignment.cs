﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RL.Data.DataModels
{
    public class ProcedureUserAssignment
    {
        public int ProcedureId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public DateTime AssignedDate { get; set; }

        public Procedure Procedure { get; set; }
        public User User { get; set; }
    }
}


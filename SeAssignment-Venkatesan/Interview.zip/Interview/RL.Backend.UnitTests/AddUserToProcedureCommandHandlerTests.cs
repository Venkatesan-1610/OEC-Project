﻿using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RL.Backend.Commands;
using RL.Backend.Commands.Handlers.Users;
using RL.Backend.Exceptions;
using RL.Data;
using RL.Data.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RL.Backend.UnitTests
{
    [TestClass]
    public class AddUserToProcedureCommandHandlerTests
    {
        private RLContext _context;
        private AddUserToProcedureCommandHandler _handler;

        [TestInitialize]
        public void Setup()
        {
            _context = DbContextHelper.CreateContext(); 
            _handler = new AddUserToProcedureCommandHandler(_context);
        }

        [TestMethod]
        [DataRow(-1)]
        [DataRow(0)]
        [DataRow(int.MinValue)]
        public async Task AddUserToProcedure_InvalidProcedureId_ReturnsBadRequest(int procedureId)
        {
            var request = new AddUserToProcedureCommand()
            {
                ProcedureId = procedureId,
                Users = new List<AssignUser> { new AssignUser { UserId = 1, UserName = "User1" } }
            };

            var result = await _handler.Handle(request, new CancellationToken());

            result.Exception.Should().BeOfType<BadRequestException>();
            result.Succeeded.Should().BeFalse();
        }

        [TestMethod]
        public async Task AddUserToProcedure_ProcedureNotFound_ReturnsNotFound()
        {
            var request = new AddUserToProcedureCommand()
            {
                ProcedureId = 1,
                Users = new List<AssignUser> { new AssignUser { UserId = 1, UserName = "User1" } }
            };

            var result = await _handler.Handle(request, new CancellationToken());

            result.Exception.Should().BeOfType<NotFoundException>();
            result.Succeeded.Should().BeFalse();
        }

        [TestMethod]
        public async Task AddUserToProcedure_UserNotFound_ReturnsNotFound()
        {
            var request = new AddUserToProcedureCommand()
            {
                ProcedureId = 1,
                Users = new List<AssignUser>
                {
                    new AssignUser { UserId = 1, UserName = "User1" },
                    new AssignUser { UserId = 2, UserName = "User2" }
                }
            };

            _context.Procedures.Add(new Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });
            await _context.SaveChangesAsync();

            var result = await _handler.Handle(request, new CancellationToken());

            result.Exception.Should().BeOfType<NotFoundException>();
            result.Succeeded.Should().BeFalse();
        }

        [TestMethod]
        public async Task AddUserToProcedure_UserAlreadyAssigned_ReturnsSuccess()
        {
            
            var existingAssignments = new List<ProcedureUserAssignment>
    {
        new ProcedureUserAssignment
        {
            ProcedureId = 1,
            UserId = 1,
            UserName = "User1",
            AssignedDate = DateTime.UtcNow
        }
    };

            _context.Procedures.Add(new Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });

            _context.Users.AddRange(new List<User>
    {
        new User { UserId = 1, Name = "User1", CreateDate = DateTime.UtcNow, UpdateDate = DateTime.UtcNow },
        new User { UserId = 2, Name = "User2", CreateDate = DateTime.UtcNow, UpdateDate = DateTime.UtcNow }
    });

            _context.procedureUserAssignments.AddRange(existingAssignments);
            await _context.SaveChangesAsync();

            var request = new AddUserToProcedureCommand()
            {
                ProcedureId = 1,
                Users = new List<AssignUser>
        {
            new AssignUser { UserId = 1, UserName = "User1" }, 
            new AssignUser { UserId = 2, UserName = "User2" }  
        }
            };

       
            var result = await _handler.Handle(request, new CancellationToken());


            result.Succeeded.Should().BeTrue("The command should succeed even if some users are already assigned.");

            var assignmentsInDb = await _context.procedureUserAssignments
                .Where(pu => pu.ProcedureId == 1)
                .ToListAsync();

            assignmentsInDb.Should().HaveCount(2, "Both existing and new assignments should be in the database.");
            assignmentsInDb.Should().ContainSingle(a => a.UserId == 1, "Existing user should still be there.");
            assignmentsInDb.Should().ContainSingle(a => a.UserId == 2, "New user should be added.");
        }



        [TestMethod]
        public async Task AddUserToProcedure_AllUsersAssigned_ReturnsSuccess()
        {
            var request = new AddUserToProcedureCommand()
            {
                ProcedureId = 1,
                Users = new List<AssignUser>
            {
                new AssignUser { UserId = 1, UserName = "User1" },
                new AssignUser { UserId = 2, UserName = "User2" }
            }
            };

            _context.Procedures.Add(new Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });

            _context.Users.AddRange(new List<User>
                {
                    new User { UserId = 1, Name = "User1", CreateDate = DateTime.UtcNow, UpdateDate = DateTime.UtcNow },
                    new User { UserId = 2, Name = "User2", CreateDate = DateTime.UtcNow, UpdateDate = DateTime.UtcNow }
                });

            await _context.SaveChangesAsync();

            var result = await _handler.Handle(request, new CancellationToken());

            result.Succeeded.Should().BeTrue();
            var assignmentsInDb = await _context.procedureUserAssignments
                .Where(pu => pu.ProcedureId == 1)
                .ToListAsync(); 
            assignmentsInDb.Should().HaveCount(2); 
        }
    }
}

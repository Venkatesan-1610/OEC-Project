﻿using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RL.Backend.Commands;
using RL.Backend.Commands.Handlers.Users;
using RL.Backend.Exceptions;
using RL.Data;
using RL.Data.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RL.Backend.UnitTests
{
    [TestClass]
    public class DeleteUserFromProcedureCommandHandlerTests
    {
        private RLContext _context;
        private DeleteUserFromProcedureCommandHandler _handler;

        [TestInitialize]
        public void Setup()
        {
            _context = DbContextHelper.CreateContext();
            _handler = new DeleteUserFromProcedureCommandHandler(_context);
        }

        [TestMethod]
        [DataRow(-1)]
        [DataRow(0)]
        [DataRow(int.MinValue)]
        public async Task DeleteUserFromProcedure_InvalidProcedureId_ReturnsBadRequest(int procedureId)
        {
            var request = new DeleteUserFromProcedureCommand()
            {
                ProcedureId = procedureId,
                UserIds = new List<int> { 1 }
            };

            var result = await _handler.Handle(request, new CancellationToken());

            result.Exception.Should().BeOfType<ArgumentException>();
            result.Succeeded.Should().BeFalse();
        }


        [TestMethod]
        public async Task DeleteUserFromProcedure_UserNotFound_ReturnsSuccess()
        {
            var request = new DeleteUserFromProcedureCommand()
            {
                ProcedureId = 1,
                UserIds = new List<int> { 1 }
            };

            var result = await _handler.Handle(request, new CancellationToken());

            result.Succeeded.Should().BeTrue();
        }


        [TestMethod]
        public async Task DeleteUserFromProcedure_UserAssigned_ReturnsSuccess()
        {
            var assignments = new List<ProcedureUserAssignment>
            {
                new ProcedureUserAssignment { ProcedureId = 1, UserId = 1, UserName = "User1", AssignedDate = DateTime.UtcNow }
            };

            _context.Procedures.Add(new Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });
            _context.procedureUserAssignments.AddRange(assignments);
            await _context.SaveChangesAsync();

            var request = new DeleteUserFromProcedureCommand()
            {
                ProcedureId = 1,
                UserIds = new List<int> { 1 }
            };

            var result = await _handler.Handle(request, new CancellationToken());

            result.Succeeded.Should().BeTrue();
            _context.procedureUserAssignments.Count().Should().Be(0); 
        }


        [TestMethod]
        public async Task DeleteUserFromProcedure_UserNotAssigned_ReturnsSuccess()
        {
            var assignments = new List<ProcedureUserAssignment>
            {
                new ProcedureUserAssignment { ProcedureId = 1, UserId = 2, UserName = "User2", AssignedDate = DateTime.UtcNow }
            };

            _context.Procedures.Add(new Procedure
            {
                ProcedureId = 1,
                ProcedureTitle = "Test Procedure"
            });
            _context.procedureUserAssignments.AddRange(assignments);
            await _context.SaveChangesAsync();

            var request = new DeleteUserFromProcedureCommand()
            {
                ProcedureId = 1,
                UserIds = new List<int> { 1 } 
            };

            var result = await _handler.Handle(request, new CancellationToken());

            result.Succeeded.Should().BeTrue();
            _context.procedureUserAssignments.Count().Should().Be(1); 
        }
    }
}
